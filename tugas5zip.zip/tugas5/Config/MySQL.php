<?php

class ConnectDB{
    public $conn;
    public function __construct()
    {
        $this->conn = mysqli_connect("localhost", "root", "", "dbkampus");
        if(!$this->conn){
            die("koneksi gagal : ".mysqli_connect_error());
        }

    }
    public function db(){
        return $this->conn;
    }
}

$db = new ConnectDB();
$conn = $db->db();
?>